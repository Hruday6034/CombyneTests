Automation instructions:
Precondition to run automation:

1. Java 8
2. Eclipse IDE 
Link: www.eclipse.org
3. Selenium Webdriver Jars(Included in the folder), Version: 3.141
Link : https://www.selenium.dev/downloads/
3. Download Microsoft Edge driver, Version 86.0.622.63 (Official build) (64-bit), This is included in the folder.
Link: https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/#downloads

Project folder name: CombyneTests
Test class name: CombyneTest.java

Run as java application.

git commands to upload project.

 git init
 git add .
 git commit -m "your message"
 git remote add origin PASTE URL
 git push -u origin master

Thank you!.

